<script>
  export let name;
</script>
<style global>
  @tailwind base;
  @tailwind components;
  @tailwind utilities;
</style>
<h1 class="text-4xl text-white bg-black">Hello {name}!</h1>
